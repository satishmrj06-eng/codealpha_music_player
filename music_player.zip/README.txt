Simple Music Player (Task 4)

Files:
- index.html
- css/style.css
- js/script.js
- audio/track1.wav, track2.wav, track3.wav (1s silent sample tracks)

How to use:
1. Unzip the folder and open index.html in a browser.
2. Replace the audio files in the audio/ folder with your own MP3/WAV files if you like.
3. Optionally update the playlist buttons in index.html with new titles and data-src paths.

This basic player supports:
- Play/Pause
- Next / Previous
- Progress bar and seeking
- Simple playlist

Made for your assignment — let me know if you want an advanced version (progress animation, volume control, drag-and-drop playlist, etc.).
