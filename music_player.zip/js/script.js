const audio = document.getElementById('audio');
const playBtn = document.getElementById('play');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const progress = document.getElementById('progress');
const title = document.getElementById('title');
const currentEl = document.getElementById('current');
const durationEl = document.getElementById('duration');
const tracks = Array.from(document.querySelectorAll('.playlist .track'));

let currentIndex = 0;
let isPlaying = false;

function loadTrack(index) {
  const t = tracks[index];
  tracks.forEach(tr => tr.classList.remove('active'));
  t.classList.add('active');
  audio.src = t.dataset.src;
  title.textContent = t.dataset.title;
  audio.load();
}

tracks.forEach((btn, i) => {
  btn.addEventListener('click', () => {
    currentIndex = i;
    loadTrack(currentIndex);
    playAudio();
  });
});

playBtn.addEventListener('click', () => {
  if (!isPlaying) playAudio();
  else pauseAudio();
});

prevBtn.addEventListener('click', () => {
  currentIndex = (currentIndex - 1 + tracks.length) % tracks.length;
  loadTrack(currentIndex);
  playAudio();
});

nextBtn.addEventListener('click', () => {
  currentIndex = (currentIndex + 1) % tracks.length;
  loadTrack(currentIndex);
  playAudio();
});

function playAudio() {
  audio.play();
  isPlaying = true;
  playBtn.textContent = '⏸️';
}

function pauseAudio() {
  audio.pause();
  isPlaying = false;
  playBtn.textContent = '▶️';
}

audio.addEventListener('timeupdate', () => {
  if (audio.duration) {
    const percent = (audio.currentTime / audio.duration) * 100;
    progress.value = percent;
    currentEl.textContent = formatTime(audio.currentTime);
    durationEl.textContent = formatTime(audio.duration);
  }
});

progress.addEventListener('input', () => {
  if (audio.duration) {
    const time = (progress.value / 100) * audio.duration;
    audio.currentTime = time;
  }
});

audio.addEventListener('ended', () => {
  nextBtn.click();
});

function formatTime(t) {
  const minutes = Math.floor(t / 60);
  const seconds = Math.floor(t % 60).toString().padStart(2,'0');
  return `${minutes}:${seconds}`;
}

// init
loadTrack(0);
